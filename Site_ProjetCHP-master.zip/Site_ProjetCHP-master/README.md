-----------------------------------------------------------
# Site Web du Projet de dernière année en filière CHP à l'ENSEIRB-MATMECA
-----------------------------------------------------------
## Site Web faisant office de compte rendu du projet effectué

**Objectif** : Implémentation d'un nouveau solveur dans le code SU2.

---

**Repertoire github**

Langage : HTML / CSS

Utilisation : Ouvrir le fichier _Accueil.html_ dans un navigateur web pour accéder au site.

Repertoire :

- Principal contenant la page d'accueil et le fichier de mise en forme des pages web,
- _pages_annexes_ contenant les autres pages web du site et accesible à partir de _accueil.html_,
- _Images_ contenant toute les images nécessaires au site web.

Copyright 2018-2019, B. Constant, M. Fleurotte, A. Motte, I Moufid et les encadrants du projet.
